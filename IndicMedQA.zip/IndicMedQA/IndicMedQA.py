from transformers import InstructBlipProcessor, InstructBlipForConditionalGeneration,AutoTokenizer,AutoModelForCausalLM,BitsAndBytesConfig
from peft import prepare_model_for_kbit_training, LoraConfig, get_peft_model,AutoPeftModelForCausalLM,PeftModel
import torch
from PIL import Image
import requests
from torch.utils.data import DataLoader
from pathlib import Path
from pytorchtools import EarlyStopping
import pandas as pd
import os
from tqdm import tqdm 
from torchvision import transforms
from torch.nn import CrossEntropyLoss
device = "cuda" if torch.cuda.is_available() else "cpu"
seed=42
torch.manual_seed(seed=seed)
torch.cuda.manual_seed_all(seed)

quant_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_use_double_quant=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16
)

model = InstructBlipForConditionalGeneration.from_pretrained("Salesforce/instructblip-flan-t5-xl",quantization_config=quant_config)
processor = InstructBlipProcessor.from_pretrained("Salesforce/instructblip-flan-t5-xl")

# loraconfig = LoraConfig(
#                 r=64, 
#                 lora_alpha=16, 
#                 target_modules=[
#                     "query",
#                     "value",
#                 ],
#                 lora_dropout=0.1, 
#                 bias="none", 
#                 task_type="SEQ_2_SEQ_LM"
#             )
# new_encoder = PeftModel(model.qformer.encoder, loraconfig)
# path_to_lora_qformer="/mnt/Data/raghav/BLIP_Indic/multimodal_exp/checkpoint_exp5_with_qformer_qformer"
# new_encoder.load_state_dict(torch.load(path_to_lora_qformer))
# model.qformer.encoder = new_encoder
for name, param in model.named_parameters():
            param.requires_grad = False


quant_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_use_double_quant=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16
)
indic_id = "sarvamai/sarvam-2b-v0.5"
indic_model=AutoModelForCausalLM.from_pretrained(indic_id,quantization_config=quant_config)
# adapter_id = "/mnt/Data/raghav/BLIP_Indic/multimodal_exp/checkpoint_exp4"
# indic_model = PeftModel.from_pretrained(indic_model, adapter_id).to(device)
indic_tokenizer=AutoTokenizer.from_pretrained(indic_id)
processor.tokenizer=indic_tokenizer

# indic_model = indic_model.merge_and_unload()
for name, param in indic_model.named_parameters():
    # print(name)
    param.requires_grad = False 


indic_model.use_cache = False
indic_model.gradient_checkpointing_enable()
indic_model.config.use_cache = False
indic_model = prepare_model_for_kbit_training(indic_model)


loraconfig = LoraConfig(
                r=64, 
                lora_alpha=128, 
                target_modules=[
                    "query",
                    "key",
                    "value",
                    "dense"

                ],
                lora_dropout=0.1, 
                bias="none", 
            )
new_encoder = PeftModel(model.qformer.encoder, loraconfig)
model.qformer.encoder=new_encoder
# Print the trainable parameters in the model
for name, param in model.named_parameters():
    if param.requires_grad:
        print(name)


loraconfig=LoraConfig(
            r=64, 
            lora_alpha=128, 
            target_modules=[
                "q_proj",
                "k_proj",
                "v_proj",
                "o_proj",
                "gate_proj",
                "up_proj",
                "down_proj",
                "lm_head",
            ],
            lora_dropout=0.1, 
            bias="none", 
            task_type="CAUSAL_LM"
        )
indic_peft_model = get_peft_model(indic_model, loraconfig)
for name, param in indic_peft_model.named_parameters():
    if param.requires_grad:
        print(name)

class Data(torch.utils.data.Dataset):
    def __init__(self,data):
        self.data=data

    def __len__(self):
        return len(self.data)

    def __getitem__(self,idx):
        img_path='/mnt/Data/akashghosh/Indic_Medical_LLM/'+self.data['Image_path'][idx]
        input_text = "Summarise the given question and comment on its severity and any additional symptoms if present in the image provided. Question: "+ str(self.data['multilingual_text'][idx])+" Summary: " + str(self.data['Final_Summary'][idx])

        sample={
            'Image_path':img_path,
            'multilingual_text':input_text
        }
        return sample
df_train=pd.read_csv('M3Help_train.csv')
df_val=pd.read_csv('M3Help_valid.csv')
exp_name="sarvam_AI"
exp_path="M3Help_weights_new_new_220625"


bm_dataset_train = Data(df_train)
dataloader_train = DataLoader(bm_dataset_train, batch_size=1,shuffle=False, num_workers=0)

print("train_data loaded")

bm_dataset_val = Data(df_val)
dataloader_val = DataLoader(bm_dataset_val, batch_size=1,shuffle=False, num_workers=0)
print("validation_data loaded")

accum_iter=4
optimizer = torch.optim.AdamW(indic_peft_model.parameters(), lr=2e-4,weight_decay=0) #lr=1e-4
epochs = 5   
train_loss_list=[]
val_loss_list=[]

    # initialize the experiment path
Path(exp_path).mkdir(parents=True, exist_ok=True)
# initialize early_stopping object
chk_file = os.path.join(exp_path, 'checkpoint_'+exp_name)
early_stopping = EarlyStopping(patience=10, verbose=True, path=chk_file)



for i in range(epochs):
    # if(i==1):
    #      break
    print("Epoch")
    print(i)
    indic_peft_model.train()
    # model.train()

    total_loss_train = 0
    total_train = 0
    correct_train = 0

    for batch_idx,data in enumerate(tqdm(dataloader_train, desc="Training", leave=False)):
        # if (batch_idx==1):
        #      break
#                 print(batch_idx)
        # try:
         
        #print(data)

        image_path=data['Image_path'][0]
        # print(data['img_path'])
        # print(image_path)
        text = data['multilingual_text'][0]
#                 print(text)
        qformer_input= "Describe the medical symptoms shown in the given image in details. Also comment on its severity and any additional symptoms if present. Description: "

        image = Image.open(image_path)
        if image.mode != "RGB":
            image = image.convert("RGB")
        prompt = text
        image_des=text.replace('\n\n', '')
        image_des=image_des.replace('\n', '')
        image_des=image_des.rstrip()
        pattern='The image'
        index=image_des.find(pattern)
        image_des=image_des[index:]
        # print(image_des)

        # inputs_main = processor(images=image, text=prompt, return_tensors="pt").to("cuda")
        inputs_main=processor.tokenizer(prompt, return_tensors="pt").to("cuda")
        inputs_des=processor.tokenizer(image_des, return_tensors="pt").to("cuda")
        inputs=processor(images=image, text=qformer_input, return_tensors="pt").to("cuda")
        vision_output = model.vision_model(pixel_values=inputs['pixel_values'].half())
        image_embeds=vision_output[0]
        image_attention_mask = torch.ones(image_embeds.size()[:-1], dtype=torch.long, device=image_embeds.device)
        query_tokens = model.query_tokens.expand(image_embeds.shape[0], -1, -1)
        query_attention_mask = torch.ones(query_tokens.size()[:-1], dtype=torch.long, device=image_embeds.device)
        qformer_attention_mask = torch.ones_like(inputs.qformer_input_ids)
        qformer_attention_mask = torch.cat([query_attention_mask, qformer_attention_mask], dim=1)
        query_outputs=model.qformer(
            input_ids=inputs.qformer_input_ids,
            attention_mask=qformer_attention_mask,
            query_embeds=query_tokens,
            encoder_hidden_states=image_embeds,
            encoder_attention_mask=image_attention_mask,
        )
        query_output=query_outputs[0][:, : query_tokens.size(1), :]
        language_model_inputs=model.language_projection(query_output)
        language_model_attention_mask = torch.ones(
            language_model_inputs.size()[:-1], dtype=torch.long, device=language_model_inputs.device
        )
        inputs_embeds=indic_model.get_input_embeddings()(inputs_main.input_ids)
        inputs_embeds = torch.cat([language_model_inputs, inputs_embeds.to(language_model_inputs.device)], dim=1)
        attention_mask = torch.ones_like(inputs.input_ids)
        attention_mask = torch.cat([language_model_attention_mask.to(attention_mask.device), attention_mask], dim=1)
        empty_ids=torch.ones(
            language_model_inputs.size()[:-1], dtype=torch.long, device=language_model_inputs.device
        ).fill_(-100)
        labels1=torch.cat([empty_ids,inputs_main.input_ids],dim=1)
        labels2=torch.cat([empty_ids,inputs_des.input_ids],dim=1)

        # outputs = indic_peft_model(
        #     inputs_embeds=inputs_embeds,
        #     attention_mask=attention_mask,
        #     labels=labels,)

        outputs = indic_peft_model(
            inputs_embeds=inputs_embeds,
            attention_mask=attention_mask,
            labels=labels1,)
        loss_full=outputs["loss"]
        # logits = outputs[0]
        # if labels1 is not None:
        #         labels1 = labels1.to(logits.device)
        #         logits = logits[:, -labels1.size(1) :, :]
        #         # Shift so that tokens < n predict n
        #         shift_logits = logits[..., :-1, :].contiguous()
        #         shift_labels1 = labels1[..., 1:].contiguous().to(logits.device)

        #         # Flatten the tokens
        #         loss_fct = CrossEntropyLoss(reduction="mean")

        #         loss1 = loss_fct(shift_logits.view(-1, indic_model.config.vocab_size), shift_labels1.view(-1))

        # if labels2 is not None:
        #         labels2 = labels2.to(logits.device)
        #         logits = logits[:, -labels2.size(1) :, :]
        #         # Shift so that tokens < n predict n
        #         shift_logits = logits[..., :-1, :].contiguous()
        #         shift_labels2 = labels2[..., 1:].contiguous().to(logits.device)

        #         # Flatten the tokens
        #         loss_fct = CrossEntropyLoss(reduction="mean")

        #         loss2 = loss_fct(shift_logits.view(-1, indic_model.config.vocab_size), shift_labels2.view(-1))

        # loss_full=0.7*loss1+0.3*loss2
        # loss_full.backward()
        # optimizer.step()
        # optimizer.zero_grad()
        # total_loss_train += loss_full.item()
        # loss = outputs["loss"]/accum_iter
        # loss.backward() #gradient
        # if((batch_idx)%accum_iter==0)or(batch_idx+1==len(dataloader_train)):
        #     optimizer.step()
        #     optimizer.zero_grad()
        #if batch_idx%3==0:
        #    print(f"Epoch:{i+1},Part1: {batch_idx+1}, Data Point: {batch_idx+1}, Loss: {loss_full.item()}")
        
        # total_loss_train += loss.item()
        image_cap_input=qformer_input+image_des

        inputs_cap=processor(images=image, text=image_cap_input, return_tensors="pt").to("cuda")
        vision_output = model.vision_model(pixel_values=inputs['pixel_values'].half())
        image_embeds=vision_output[0]
        image_attention_mask = torch.ones(image_embeds.size()[:-1], dtype=torch.long, device=image_embeds.device)
        query_tokens = model.query_tokens.expand(image_embeds.shape[0], -1, -1)
        query_attention_mask = torch.ones(query_tokens.size()[:-1], dtype=torch.long, device=image_embeds.device)
        qformer_attention_mask = torch.ones_like(inputs.qformer_input_ids)
        qformer_attention_mask = torch.cat([query_attention_mask, qformer_attention_mask], dim=1)
        query_outputs=model.qformer(
            input_ids=inputs.qformer_input_ids,
            attention_mask=qformer_attention_mask,
            query_embeds=query_tokens,
            encoder_hidden_states=image_embeds,
            encoder_attention_mask=image_attention_mask,
        )
        query_output=query_outputs[0][:, : query_tokens.size(1), :]
        language_model_inputs=model.language_projection(query_output)
        language_model_attention_mask = torch.ones(
            language_model_inputs.size()[:-1], dtype=torch.long, device=language_model_inputs.device
        )
        inputs_embeds=indic_model.get_input_embeddings()(inputs_cap.input_ids)
        inputs_embeds = torch.cat([language_model_inputs, inputs_embeds.to(language_model_inputs.device)], dim=1)
        attention_mask = torch.ones_like(inputs.input_ids)
        attention_mask = torch.cat([language_model_attention_mask.to(attention_mask.device), attention_mask], dim=1)
        empty_ids=torch.ones(
            language_model_inputs.size()[:-1], dtype=torch.long, device=language_model_inputs.device
        ).fill_(-100)
        labels=torch.cat([empty_ids,inputs_cap.input_ids],dim=1)
        outputs_cap = indic_peft_model(
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                labels=labels,)


        loss_cap = outputs_cap["loss"]
        '''
        if batch_idx%3==0:
            #print(f"Epoch:{i+1}, Part2: {batch_idx+1}, Data Point: {batch_idx+1}, Loss: {loss_cap.item()}")
        '''    
        final_loss=0.6*loss_full+0.4*loss_cap
        final_loss=final_loss/accum_iter
        total_loss_train += final_loss.item()
        
        final_loss.backward() #gradient
        # optimizer.step()
        # optimizer.zero_grad()
        if((batch_idx)%accum_iter==0)or(batch_idx+1==len(dataloader_train)):
            optimizer.step()
            optimizer.zero_grad()




        # except Exception as e:
        #     print(e)
        #     continue

    
    train_loss = total_loss_train/len(dataloader_train)
    indic_peft_model.eval()

    total_loss_val = 0
    total_val = 0
    correct_val = 0

    with torch.no_grad():
        for batch_idx,data in enumerate(tqdm(dataloader_val, desc="Validation", leave=False)): 
            # try:
                # if(batch_idx==1):
                #      break  

            image_path=data['Image_path'][0]
    #                 print(image_path)
            text = data['multilingual_text'][0]
            qformer_input= "Describe the medical symptoms shown in the given image in details. Also comment on its severity and any additional symptoms if present. Description: "
    #                 print(text)

            image = Image.open(image_path)
            prompt = text
            image_des=text.replace('\n\n', '')
            image_des=image_des.replace('\n', '')
            image_des=image_des.rstrip()
            pattern='The image'
            index=image_des.find(pattern)
            image_des=image_des[index:]
            # inputs_main = processor(images=image, text=prompt, return_tensors="pt").to("cuda")
            inputs_des=processor.tokenizer(image_des, return_tensors="pt").to("cuda")
            inputs_main=processor.tokenizer(prompt, return_tensors="pt").to("cuda")
            inputs=processor(images=image, text=qformer_input, return_tensors="pt").to("cuda")
            vision_output = model.vision_model(pixel_values=inputs['pixel_values'].half())
            image_embeds=vision_output[0]
            image_attention_mask = torch.ones(image_embeds.size()[:-1], dtype=torch.long, device=image_embeds.device)
            query_tokens = model.query_tokens.expand(image_embeds.shape[0], -1, -1)
            query_attention_mask = torch.ones(query_tokens.size()[:-1], dtype=torch.long, device=image_embeds.device)
            qformer_attention_mask = torch.ones_like(inputs.qformer_input_ids)
            qformer_attention_mask = torch.cat([query_attention_mask, qformer_attention_mask], dim=1)
            query_outputs=model.qformer(
                input_ids=inputs.qformer_input_ids,
                attention_mask=qformer_attention_mask,
                query_embeds=query_tokens,
                encoder_hidden_states=image_embeds,
                encoder_attention_mask=image_attention_mask,
            )
            #print("Model QFormer")
            #print(query_outputs)
            query_output=query_outputs[0][:, : query_tokens.size(1), :]
            language_model_inputs=model.language_projection(query_output)
            #print("Language proj")
            #print(language_model_inputs)
            language_model_attention_mask = torch.ones(
                language_model_inputs.size()[:-1], dtype=torch.long, device=language_model_inputs.device
            )
            inputs_embeds=indic_model.get_input_embeddings()(inputs_main.input_ids)
            inputs_embeds = torch.cat([language_model_inputs, inputs_embeds.to(language_model_inputs.device)], dim=1)
            attention_mask = torch.ones_like(inputs.input_ids)
            attention_mask = torch.cat([language_model_attention_mask.to(attention_mask.device), attention_mask], dim=1)
            empty_ids=torch.ones(
                language_model_inputs.size()[:-1], dtype=torch.long, device=language_model_inputs.device
            ).fill_(-100)
            # labels=torch.cat([empty_ids,inputs_main.input_ids],dim=1)
            labels1=torch.cat([empty_ids,inputs_main.input_ids],dim=1)
            labels2=torch.cat([empty_ids,inputs_des.input_ids],dim=1)
            # indic_peft_model.zero_grad()
            # model.zero_grad()

            # outputs = indic_peft_model(
            #     inputs_embeds=inputs_embeds,
            #     attention_mask=attention_mask,
            #     labels=labels,)


            # val_loss = outputs["loss"]
            outputs = indic_peft_model(
            inputs_embeds=inputs_embeds,
            attention_mask=attention_mask,
            labels=labels1,)
            loss_full_val=outputs["loss"]
            # logits = outputs[0]
            # if labels1 is not None:
            #         labels1 = labels1.to(logits.device)
            #         logits = logits[:, -labels1.size(1) :, :]
            #         # Shift so that tokens < n predict n
            #         shift_logits = logits[..., :-1, :].contiguous()
            #         shift_labels1 = labels1[..., 1:].contiguous().to(logits.device)

            #         # Flatten the tokens
            #         loss_fct = CrossEntropyLoss(reduction="mean")

            #         loss1 = loss_fct(shift_logits.view(-1, indic_model.config.vocab_size), shift_labels1.view(-1))

            # if labels2 is not None:
            #         labels2 = labels2.to(logits.device)
            #         logits = logits[:, -labels2.size(1) :, :]
            #         # Shift so that tokens < n predict n
            #         shift_logits = logits[..., :-1, :].contiguous()
            #         shift_labels2 = labels2[..., 1:].contiguous().to(logits.device)

            #         # Flatten the tokens
            #         loss_fct = CrossEntropyLoss(reduction="mean")

            #         loss2 = loss_fct(shift_logits.view(-1, indic_model.config.vocab_size), shift_labels2.view(-1))

            # loss_full_val=0.7*loss1+0.3*loss2


            image_cap_input=qformer_input+image_des

            inputs_cap=processor(images=image, text=image_cap_input, return_tensors="pt").to("cuda")
            vision_output = model.vision_model(pixel_values=inputs['pixel_values'].half())
            image_embeds=vision_output[0]
            image_attention_mask = torch.ones(image_embeds.size()[:-1], dtype=torch.long, device=image_embeds.device)
            query_tokens = model.query_tokens.expand(image_embeds.shape[0], -1, -1)
            query_attention_mask = torch.ones(query_tokens.size()[:-1], dtype=torch.long, device=image_embeds.device)
            qformer_attention_mask = torch.ones_like(inputs.qformer_input_ids)
            qformer_attention_mask = torch.cat([query_attention_mask, qformer_attention_mask], dim=1)
            query_outputs=model.qformer(
                input_ids=inputs.qformer_input_ids,
                attention_mask=qformer_attention_mask,
                query_embeds=query_tokens,
                encoder_hidden_states=image_embeds,
                encoder_attention_mask=image_attention_mask,
            )
            query_output=query_outputs[0][:, : query_tokens.size(1), :]
            language_model_inputs=model.language_projection(query_output)
            language_model_attention_mask = torch.ones(
                language_model_inputs.size()[:-1], dtype=torch.long, device=language_model_inputs.device
            )
            inputs_embeds=indic_model.get_input_embeddings()(inputs_cap.input_ids)
            inputs_embeds = torch.cat([language_model_inputs, inputs_embeds.to(language_model_inputs.device)], dim=1)
            attention_mask = torch.ones_like(inputs.input_ids)
            attention_mask = torch.cat([language_model_attention_mask.to(attention_mask.device), attention_mask], dim=1)
            empty_ids=torch.ones(
                language_model_inputs.size()[:-1], dtype=torch.long, device=language_model_inputs.device
            ).fill_(-100)
            labels=torch.cat([empty_ids,inputs_cap.input_ids],dim=1)
            outputs_cap = indic_peft_model(
                    inputs_embeds=inputs_embeds,
                    attention_mask=attention_mask,
                    labels=labels,)


            loss_cap_val = outputs_cap["loss"]
            final_loss_val=0.6*loss_full_val+0.4*loss_cap_val
            total_loss_val += final_loss_val.item()
            # val_loss = loss

            
            # total_loss_val += loss_full_val.item()
            # except Exception as e: 
            #     print(e)
            #     continue



    val_loss = total_loss_val/len(dataloader_val)


    train_loss_list.append(train_loss)
    val_loss_list.append(val_loss)
    # model.language_model=indic_peft_model
    peft_qformer_encoder=model.qformer.encoder
    early_stopping(val_loss,qformer=peft_qformer_encoder,model=indic_peft_model,tokenizer=indic_tokenizer)
    # early_stopping(val_loss, model,tokenizer=processor)
    

    if early_stopping.early_stop:
            print("Early stopping")
            # break
        

    
    print(f'Epoch {i+1}: train_loss: {train_loss:.4f} | val_loss: {val_loss:.4f}')
    torch.cuda.empty_cache()



